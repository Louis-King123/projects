#!/usr/bin/python
# -*- coding: utf-8 -*-
# @Time    : 2021/4/6 14:17
# @Author  : yangxin
# @FileName: local_settings.py
# @Software: PyCharm
# @Desc    :
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'operate_manage_platform',
        'USER': 'root',
        # 'PASSWORD': 'yangxin',
        'PASSWORD': '920403Love',
        'HOST': '127.0.0.1',
        'PORT': '3306',
    },
    'oracle': {
        'ENGINE': 'django.db.backends.oracle',
        'NAME': '192.168.149.131:1521/XE',
        'USER': 'ITEST',
        'PASSWORD': '123456',
    }
}


CACHES = {
    "default": {
        "BACKEND": "django_redis.cache.RedisCache",
        "LOCATION": "redis://127.0.0.1:6379/1",
        "OPTIONS": {
            "CLIENT_CLASS": "django_redis.client.DefaultClient",
        }
    }
}
